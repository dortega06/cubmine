/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dortega- <dortega-@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/30 17:05:19 by dortega-          #+#    #+#             */
/*   Updated: 2026/04/18 19:17:34 by dortega-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CUB_H
# define CUB_H

/********************************[ macros ]************************************/

# define WIDTH 1280
# define HEIGHT 720
# define BLOCK  64

# define A 97
# define W 119
# define S 115
# define D 100
# define LEFT 65361
# define RIGHT 65363
# define ESC 65307
# define PI 3.1415926535

/********************************[ libs ]**************************************/

# include "../mlx/mlx.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
/*******************************[ structs ]************************************/

typedef struct s_player
{
	float	x;
	float	y;
	float	angle;

	bool	key_up;
	bool	key_down;
	bool	key_left;
	bool	key_right;

	bool	left_rotate;
	bool	right_rotate;
}	t_player;

typedef struct s_game
{
	void	*mlx;
	void	*wnd;
	void	*img;

	char *data;
	int	bpp;
	int	size_line;
	int endian;
	t_player	player;

	char **map;
}	t_game;

/*******************************[ ft ]************************************/

void	init_player(t_player *player);
int key_realese(int keycode, t_game *game);
int key_press(int keycode, t_game *game);
void    move_player(t_player *player);
float distance(float dx, float dy);
void    clear_img(t_game *game);
bool touch(float px, float py, t_game *game);
float   fixed_distance(float x1, float y1, float x2, float y2, t_game *game);
int	close_game(t_game *game);
/*******************************[ render ]*********************************/
int	draw_loop(t_game *game);
void	draw_map(t_game *game);
void	draw_square(int x, int y, int size, int color, t_game *game);
void	put_pixel(int x, int y, int color, t_game *game);
void	draw_line(t_player *player, t_game *game, float start_x, int i);
#endif
