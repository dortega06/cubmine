/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   moves.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dortega- <dortega-@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/31 12:43:26 by dortega-          #+#    #+#             */
/*   Updated: 2026/04/18 19:16:34 by dortega-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/cub.h"

float	distance(float dx, float dy)
{
	return (sqrtf(dx * dx + dy * dy));
}

void	init_player(t_player *player)
{
	player->x = WIDTH / 2;
	player->y = HEIGHT / 2;
	player->angle = PI / 2;
	player->key_up = false;
	player->key_down = false;
	player->key_left = false;
	player->key_right = false;
	player->left_rotate = false;
	player->right_rotate = false;
}

int	key_realese(int keycode, t_game *game)
{
	/*
	if (keycode == W)
		player->key_up = false;
	if (keycode == S)
		player->key_down = false;
	if (keycode == A)
		player->key_left = false;
	if (keycode == D)
		player->key_right = false;
	if (keycode == LEFT)
		player->left_rotate = false;
	if (keycode == RIGHT)
		player->right_rotate = false;
	return (0);*/

	t_player	*player;

	player = &game->player;
	if (keycode == W)
		player->key_up = false;
	if (keycode == S)
		player->key_down = false;
	if (keycode == A)
		player->key_left = false;
	if (keycode == D)
		player->key_right = false;
	if (keycode == LEFT)
		player->left_rotate = false;
	if (keycode == RIGHT) 
		player->right_rotate = false;
	return (0);
}

int	key_press(int keycode, t_game *game)
{
/*	if (keycode == ESC)
		return (close_game(game));
	if (keycode == W)
		player->key_up = true;
	if (keycode == S)
		player->key_down = true;
	if (keycode == A)
		player->key_left = true;
	if (keycode == D)
		player->key_right = true;
	if (keycode == LEFT)
		player->left_rotate = true;
	if (keycode == RIGHT)
		player->right_rotate = true;
	return (0);*/
	t_player	*player = &game->player;

	if (keycode == ESC)
		return (close_game(game));

	if (keycode == W) player->key_up = true;
	if (keycode == S) player->key_down = true;
	if (keycode == A) player->key_left = true;
	if (keycode == D) player->key_right = true;
	if (keycode == LEFT) player->left_rotate = true;
	if (keycode == RIGHT) player->right_rotate = true;
	return (0);
}

void	move_player(t_player *player)
{
	double	speed;
	double	angle_speed;
	double	cos_angle;
	double	sin_angle;

	speed = 2;
	angle_speed = 0.03;
	cos_angle = cos(player->angle);
	sin_angle = sin(player->angle);
	if (player->left_rotate)
		player->angle -= angle_speed;
	if (player->right_rotate)
		player->angle += angle_speed;
	if (player->angle > 2 * PI)
		player->angle = 0;
	if (player->angle < 0)
		player->angle = 2 * PI;
	if (player->key_up)
	{
		player->x += cos_angle * speed;
		player->y += sin_angle * speed;
	}
	if (player->key_down)
	{
		player->x -= cos_angle * speed;
		player->y -= sin_angle * speed;
	}
	if (player->key_right)
	{
		player->x += cos(player->angle + PI / 2) * speed;
		player->y += sin(player->angle + PI / 2) * speed;
	}
	if (player->key_left)
	{
		player->x += cos(player->angle - PI / 2) * speed;
		player->y += sin(player->angle - PI / 2) * speed;
	}
}
