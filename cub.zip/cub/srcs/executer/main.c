/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dortega- <dortega-@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/30 17:08:31 by dortega-          #+#    #+#             */
/*   Updated: 2026/04/18 19:20:08 by dortega-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/cub.h"
#include <math.h>

void	clear_img(t_game *game)
{
	for(int y = 0; y < HEIGHT; y++)
	{
		for (int x = 0; x < WIDTH; x++)
			put_pixel(x, y, 0, game);
	}
}
/*
char **get_map(void)
{
	char **map = malloc(sizeof(char *) * 6);
	map[0] = "111111";
	map[1] = "100001";
	map[2] = "100001";
	map[3] = "100001";
	map[4] = "111111";
	map[5] = NULL;
	return (map);
}*/

char **get_map(void)
{
    char **map = malloc(sizeof(char *) * 11);
    map[0] = "111111111111111";
    map[1] = "100000000000001";
    map[2] = "100000000000001";
    map[3] = "100000100000001";
    map[4] = "100000000000001";
    map[5] = "100000010000001";
    map[6] = "100001000000001";
    map[7] = "100000000000001";
    map[8] = "100000000000001";
    map[9] = "111111111111111";
    map[10] = NULL;
    return (map);
}

void	init_game(t_game *game)
{
	init_player(&game->player);
	game->map = get_map();
	game->mlx = mlx_init();
	game->wnd = mlx_new_window(game->mlx, WIDTH, HEIGHT, "Game");
	game->img = mlx_new_image(game->mlx, WIDTH, HEIGHT);
	game->data = mlx_get_data_addr(game->img, &game->bpp,
			&game->size_line, &game->endian);
	mlx_put_image_to_window(game->mlx, game->wnd, game->img, 0, 0);
}

bool touch(float px, float py, t_game *game)
{
	int	x = px / BLOCK;
	int	y = py / BLOCK;

	if (px < 0 || py < 0 || px >= WIDTH || py >= HEIGHT)
		return true;

	// fuera del mapa => pared
	if (y < 0 || !game->map[y])
		return true;
	if (x < 0 || x >= (int)strlen(game->map[y]))
		return true;
	if (game->map[y][x] == '1')
		return (true);
	return false;
}

float	fixed_distance(float x1, float y1, float x2, float y2, t_game *game)
{
	float delta_x = x2 - x1;
	float delta_y = y2 - y1;
	float angle = atan2(delta_y, delta_x) - game->player.angle;
	float fix_dist = distance(delta_x, delta_y) * cos(angle);
	return fix_dist;
}

int	main(void)
{
	t_game	game;
	init_game(&game);
	mlx_hook(game.wnd, 2, 1L<<0, key_press, &game);
	mlx_hook(game.wnd, 3, 1L<<1, key_realese, &game);
	
	mlx_hook(game.wnd, 17, 0, close_game, &game);
	
	mlx_loop_hook(game.mlx, draw_loop, &game);
	mlx_loop(game.mlx);
	return (0);
}
