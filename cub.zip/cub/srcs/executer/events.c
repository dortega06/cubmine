/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   events.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dortega- <dortega-@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/04/03 19:07:38 by dortega-          #+#    #+#             */
/*   Updated: 2026/04/18 19:22:25 by dortega-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../inc/cub.h"

int	close_game(t_game *game)
{
	if (!game)
		exit(0);

	if (game->img)
		mlx_destroy_image(game->mlx, game->img);
	if (game->wnd)
		mlx_destroy_window(game->mlx, game->wnd);

	// tu map: solo se hizo malloc del char** (88 bytes), las filas son literales
	if (game->map)
		free(game->map);

	// Linux/X11 MLX
	if (game->mlx)
	{
		mlx_destroy_display(game->mlx);
		free(game->mlx);
	}

	exit(0);
	return (0);
}
